package Pack_pr;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.lang.*;


public class Caculate_update {
	public static void main(String[] args) {
		final JFrame f = new JFrame("CACULATOR");
		final JTextField t1, t2;
		final JLabel t3;
		final JButton plus;
		final JButton sub;
		final JButton multi;
		final JButton divide;
		final JButton divide2;
		final JButton Squareroot;
		final JButton Square;
		final JButton Ac;
		final JButton Delete;
		final JButton Ans;
		final JButton Bspace;
		
		t1 = new JTextField(120);
	
		t1.setBounds(50, 70, 380, 50);
		
		t2 = new JTextField(120);
	
		t2.setBounds(50, 150, 380, 50);
		
		
		t3 = new JLabel("");
		t3.setBounds(190, 200, 150, 50);
		
		plus = new JButton("+");
		sub = new JButton("-");
		multi = new JButton("x");
		divide = new JButton("/");
		divide2 = new JButton("%");
		Squareroot = new JButton("√a");
		Square = new JButton("^2");
		Ac = new JButton("CE");
		Delete = new JButton("DEL");
		Ans = new JButton("Ans");
		Bspace = new JButton("BSPACE");
		
		plus.setBounds(50, 270, 80, 80);
		sub.setBounds(150, 270, 80, 80);
		multi.setBounds(250, 270, 80, 80);
		Ans.setBounds(350, 270, 80, 80);
		Ac.setBounds(350, 370, 80, 180);
		divide.setBounds(50, 370, 80, 80);
		divide2.setBounds(150, 370, 80, 80);
		Squareroot.setBounds(250, 370, 80, 80);
		Square.setBounds(50, 470, 80, 80);
		Delete.setBounds(150, 470, 80, 80);
		Bspace.setBounds(250, 470, 80, 80);
		
		Font font = new Font("Arial", Font.PLAIN, 30);
		
		t1.setFont(font);
		t2.setFont(font);
		t3.setFont(font);
		t3.setForeground(Color.WHITE);
		
		plus.setBackground(Color.LIGHT_GRAY);
		sub.setBackground(Color.LIGHT_GRAY);
		multi.setBackground(Color.LIGHT_GRAY);
		divide.setBackground(Color.LIGHT_GRAY);
		divide2.setBackground(Color.LIGHT_GRAY);
		Squareroot.setBackground(Color.LIGHT_GRAY);
		Square.setBackground(Color.LIGHT_GRAY);
		Ac.setBackground(Color.LIGHT_GRAY);
		Delete.setBackground(Color.LIGHT_GRAY);
		Ans.setBackground(Color.LIGHT_GRAY);
		Bspace.setBackground(Color.LIGHT_GRAY);
		
	
		f.add(t1);
		
	
		f.add(t2);
		f.add(t3);
		
		f.add(plus);
		f.add(sub);
		f.add(multi);
		f.add(divide2);
		f.add(divide);
		f.add(Square);
		f.add(Squareroot);
		f.add(Ac);
		f.add(Delete);
		f.add(Ans);
		f.add(Bspace);
		
		
		plus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					double res = first + second;
					t3.setText(""+(float) res);
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");				
				}
			}
		});
		sub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					double res = first - second;
					t3.setText(""+res);
				} catch (NumberFormatException ex) {
					t3.setText("Error");				
				}
			}
		});
		multi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					double res = first * second;
					t3.setText(""+(float) res);
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");				
				}
			}
		});
		divide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					double res = first / second;
					if (first == 0 || second == 0) {
						JOptionPane.showMessageDialog(null, "Phép tính không thể thực hiện", "Thông báo", JOptionPane.ERROR_MESSAGE);
					}
					else {
						t3.setText(""+(int) res);
					}
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		divide2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					double res = first % second;
					if ((first < second) || (first == 0 || second == 0)) {
						JOptionPane.showMessageDialog(null, "Phép tính không thể thực hiện", "Thông báo", JOptionPane.ERROR_MESSAGE);
					}
					else {
						t3.setText(""+res);
					}
				} catch (NumberFormatException ex) {
					t3.setText("Error");			
                 }
			}
		});
		Squareroot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					double res = first % second;
					t3.setText("");
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		Ac.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					t3.setText("");
					t1.setText("");
					t2.setText("");
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		Square.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					if(e.getSource() == Square || e.getSource() == t1) {
						double result = Math.pow(first, 2);
						t1.setText(""+result);
						double result2 = Math.pow(second, 2);
						t2.setText(""+result2);
					}
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		Squareroot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double first = Double.parseDouble(t1.getText());
					double second = Double.parseDouble(t2.getText());
					if(e.getSource() == Squareroot ) {
						double result = Math.sqrt(first);
						t1.setText(""+result);
						double result2 = Math.sqrt(second);
						t2.setText(""+result2);
					}
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		Bspace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String Text1 = t1.getText();
					String Text2 = t2.getText();
					if(!t1.getText().isEmpty()) {
						t1.setText(Text1.substring(0, Text1.length() - 1));
						
					}
					else if(!t2.getText().isEmpty()) {
						
						t2.setText(Text2.substring(0, Text2.length() - 1));

					}
					
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String Text1 = t1.getText();
					String Text2 = t2.getText();
					if(!t1.getText().isEmpty()) {
						t1.setText(Text1.substring(1));
						
					}
					else if(!t2.getText().isEmpty()) {
						
						t2.setText(Text2.substring(1));

					}
					
					
				} catch (NumberFormatException ex) {
					t3.setText("Error");
				}
			}
		});
		
		
		
		f.setResizable(false);
		f.getContentPane().setBackground(Color.black);
		f.setSize(500, 700);
		f.setLayout(null);
		f.setVisible(true);
	}
}
